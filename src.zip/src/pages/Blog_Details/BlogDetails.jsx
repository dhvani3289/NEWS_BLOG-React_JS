

function BlogDetails() {

    return (
        <>
            blog details

        </>
    )
}

export default BlogDetails